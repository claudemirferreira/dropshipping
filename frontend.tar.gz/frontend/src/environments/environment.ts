export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080',
  supportEmail: 'suporte@dropshipping.com',
  supportWhatsapp: '+5511999999999',
};
