export const environment = {
  production: true,
  apiUrl: '/api',
  supportEmail: 'suporte@dropshipping.com',
  supportWhatsapp: '+5511999999999',
};
